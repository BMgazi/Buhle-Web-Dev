
var leaveApplicantsData = [
    { name: 'James', lastName: 'Chimire', department: 'Accounting', leaveDay: '2024-07-20', status: 'Pending' },
    { name: 'Ariana', lastName: 'Grande', department: 'Analytics', leaveDay: '2024-07-21', status: 'Approved' },
    { name: 'Dennis', lastName: 'Munyama', department: 'Electronics', leaveDay: '2024-07-20', status: 'Pending' },
    { name: 'Jane', lastName: 'Smith', department: 'Support', leaveDay: '2024-07-21', status: 'Approved' },
    { name: 'Trish', lastName: 'Chandirekera', department: 'Accounting', leaveDay: '2024-07-20', status: 'Pending' },
    { name: 'Bongani', lastName: 'Mgazi', department: 'Electronics', leaveDay: '2024-07-21', status: 'Approved' },
    { name: 'James', lastName: 'Chimire', department: 'Accounting', leaveDay: '2024-07-20', status: 'Pending' },
    { name: 'Ariana', lastName: 'Grande', department: 'Analytics', leaveDay: '2024-07-21', status: 'Approved' },
    { name: 'Dennis', lastName: 'Munyama', department: 'Electronics', leaveDay: '2024-07-20', status: 'Pending' },
    { name: 'Jane', lastName: 'Smith', department: 'Support', leaveDay: '2024-07-21', status: 'Approved' },
    { name: 'Trish', lastName: 'Chandirekera', department: 'Accounting', leaveDay: '2024-07-20', status: 'Pending' },
    { name: 'Bongani', lastName: 'Mgazi', department: 'Electronics', leaveDay: '2024-07-21', status: 'Approved' },
    { name: 'James', lastName: 'Chimire', department: 'Accounting', leaveDay: '2024-07-20', status: 'Pending' },
    { name: 'Ariana', lastName: 'Grande', department: 'Analytics', leaveDay: '2024-07-21', status: 'Approved' },
    { name: 'Dennis', lastName: 'Munyama', department: 'Electronics', leaveDay: '2024-07-20', status: 'Pending' },
    { name: 'Jane', lastName: 'Smith', department: 'Support', leaveDay: '2024-07-21', status: 'Approved' },
    { name: 'Trish', lastName: 'Chandirekera', department: 'Accounting', leaveDay: '2024-07-20', status: 'Pending' },
    { name: 'Bongani', lastName: 'Mgazi', department: 'Electronics', leaveDay: '2024-07-21', status: 'Approved' },
    
    
    
];

//populate the table 
function populateTable() {
    var tableBody = document.querySelector('#leaveApplicants tbody');

    leaveApplicantsData.forEach(function (applicant) {
        var row = tableBody.insertRow(-1);
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        var cell4 = row.insertCell(3);
        var cell5 = row.insertCell(4);
        var cell6 = row.insertCell(5);

        cell1.textContent = applicant.name;
        cell2.textContent = applicant.lastName;
        cell3.textContent = applicant.department;
        cell4.textContent = applicant.leaveDay;
        cell5.textContent = applicant.status;

        var approvalButton = document.createElement('button');
        approvalButton.textContent = 'Approve';
        approvalButton.addEventListener('click', function () {
            cell5.textContent = 'Approved';
        });
        cell6.appendChild(approvalButton);

        var disapprovalButton = document.createElement('button');
        disapprovalButton.textContent = 'Disapprove';
        disapprovalButton.addEventListener('click', function () {
            cell5.textContent = 'Not Approved';
        });
        cell6.appendChild(disapprovalButton);
    });
}

// Populate the table when the page is loaded
populateTable();