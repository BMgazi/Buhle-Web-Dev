(async function () {

	const employeeList = document.querySelector(
		".employees__names--list"
	);
	const employeeInfo = document.querySelector(
		".employees__single--info"
	);

	// Add Employee - START 
	const createEmployee = document.querySelector(
		".createEmployee"
	);
	const addEmployeeModal =
		document.querySelector(".addEmployee");
	const addEmployeeForm = document.querySelector(
		".addEmployee_create"
	);

	createEmployee.addEventListener("click", () => {
		addEmployeeModal.style.display = "flex";
	});

	addEmployeeModal.addEventListener("click", (e) => {
		if (e.target.className === "addEmployee") {
			addEmployeeModal.style.display = "none";
		}
	});

	// Set Employee age to be entered minimum 18 years 
	const dobInput = document.querySelector(
		".addEmployee_create--dob"
	);
	dobInput.max = `${new Date().getFullYear() - 18
		}-${new Date().toISOString().slice(5, 10)}`;


	document.addEventListener('DOMContentLoaded', () => {
		const employeeForm = document.querySelector('.addEmployee_create');
		const employeeList = document.querySelector('.employees__names--list');
		const employeeInfo = document.querySelector('.employees__single--info');

		employeeForm.addEventListener('submit', (e) => {
			e.preventDefault();

			const firstName = e.target.firstName.value;
			const lastName = e.target.lastName.value;
			const email = e.target.email.value;
			const contactNumber = e.target.contactNumber.value;
			const salary = e.target.salary.value;
			const address = e.target.address.value;
			const dob = e.target.dob.value;
			const imageUrl = e.target.imageUrl.value || 'default.jpg';

			const employee = {
				imageUrl,
				firstName,
				lastName,
				email,
				contactNumber,
				salary,
				address,
				dob,
				
			};

			addEmployeeToList(employee);
			e.target.reset();
		});

		function addEmployeeToList(employee) {
			const employeeItem = document.createElement('div');
			employeeItem.classList.add('employee-item');
			employeeItem.textContent = `${employee.firstName} ${employee.lastName}`;
			employeeItem.addEventListener('click', () => displayEmployeeInfo(employee));
			employeeList.appendChild(employeeItem);
		}

		function displayEmployeeInfo(employee) {
			employeeInfo.innerHTML = `
			<img src="${employee.imageUrl}" alt="${employee.firstName} ${employee.lastName}">
					<h2>${employee.firstName} ${employee.lastName}</h2>
					<p>Email: ${employee.email}</p>
					<p>Contact: ${employee.contactNumber}</p>
					<p>Salary: ${employee.salary}</p>
					<p>Address: ${employee.address}</p>
					<p>Date of Birth: ${employee.dob}</p>
					
				`;
		}
	});
	
})();